var module = angular.module('loginReg.zhuce',['ngRoute']);
module.config(['$routeProvider',function ($routeProvider) {
    $routeProvider.when('/zhuce',{
        templateUrl : 'zhuce/view.html',
        controller:'zhuceController'
    })
}])
module.controller("zhuceController",['$scope',function ($scope) {

}])
