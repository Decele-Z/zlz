var module = angular.module('loginReg.denglu',['ngRoute']);
module.config(['$routeProvider',function ($routeProvider) {
    $routeProvider.when('/denglu',{
        templateUrl : 'denglu/view.html',
        controller:'dengluController'
    })
}])
module.controller("dengluController",['$scope',function ($scope) {

}])
